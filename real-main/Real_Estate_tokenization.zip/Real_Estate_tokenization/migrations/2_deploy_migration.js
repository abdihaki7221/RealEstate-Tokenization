const landContract = artifacts.require("Real_Estate");

module.exports = function(deployer) {
  deployer.deploy(landContract);
};
