String mapBoxApiKey =
    'pk.eyJ1IjoiaGFrZWVtaXNzYW5kcm8iLCJhIjoiY2wzYTN1aXJ1MDF2bTNrb2lwODNpNDVhayJ9.z9U-41rcH6jqHo8V_R6mlg';

String nftStorageApiKey =
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJkaWQ6ZXRocjoweEIwNzlmYTNkOGZDOTUwZGFBYTJCOUQ2NzhlMjQwODEzMDQ5REM2MDIiLCJpc3MiOiJuZnQtc3RvcmFnZSIsImlhdCI6MTY1Mjc4OTIzMDgwMiwibmFtZSI6ImNyeXB0b0Fzc2FzaW4ifQ.aRbeV4r-XFSJqsEdCdQvacIv8cJQRbqmAzds9tdEbm4';

const String rpcUrl = "http://127.0.0.1:8545";
//"http://127.0.0.1:7545";

const String contractAddress = "0xEe0f70B11d049a53cF5aD01cCBBEF26625a424F7";


const int chainId = 1337; //Ropsten-3, Polygon testnet-80001, local ganache-1337
